<?php
require_once 'lib/Igo.php';
$igo = new Igo("./ipadic", "UTF-8");

$text = file_get_contents('data.txt');
$result = $igo->wakati($text);
$result = array_count_values($result);
arsort($result);

foreach ($result as $key => $val) {
    echo $key . '            ' . $val . PHP_EOL;
}
