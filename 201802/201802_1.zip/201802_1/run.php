
<?php

define('QR_URI', 'http://chart.apis.google.com/chart');

// 画像数が多い場合にタイムアウトになるのを防ぐ
set_time_limit(0);

// ここに配列でデータを格納しておく(URLとかmailtoのリンクとか)
$data = array(
    "url1" => "http://www.giants.jp/top.html",
    "url2" => "https://www.amazon.co.jp/dp/B01BHPEC9G",
    "url3" => "http://www.cosme.net/product/product_id/10023860/top"
);

foreach($data as $key => $var) {
  $imgfile = 'img/' . $key . '.png';
  if (!file_exists($imgfile)) {
    $qr = QR_URI . '?chs=200x200&cht=qr&chld=m|1&chl=' . urlencode($var);
    copy($qr, $imgfile);
  }
}
?>